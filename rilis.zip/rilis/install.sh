#!/bin/bash
echo "Installing Python modules..."
pip install -r requirements.txt
echo "Installation complete."
